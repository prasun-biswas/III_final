for(var i=0; i<2 ; i++) {

    for (var j = 0; j <3; j++)

        console.log('i: ' + i + ', j:' + j);
}