1. Run the Fastory Simualtor
2. Run the Agents.
3. Open the UI on port 5000
4. Place an Order.
5. Manually Load pallets = the number ordered.

